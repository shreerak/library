function validate(){
	
	var username=$("#username").val();
	var user_id=$("#user_id").val();
	//var pattern=$("#(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,})").val();
	
	
	var messages=[];
	
	
	if(!username && !user_id ){
		messages.push("username and password are mandatory ");
		
	}
	
	
	
	if(!username ){
		messages.push("username is mandatory ");
		
	}
	
	if( username.length<3 || username.length>15){
		messages.push("username must be between 3 to 15 letters");
	}
	
	if(!user_id ){
		messages.push("password is mandatory");
		
	}
	if( user_id.length<2 || user_id.length>8){
		messages.push("password should be more than 2 and less than 8");
	}
	
	
	
	if(messages.length>0){
		var errors = $("<ul>").addClass("alert alert-danger");
		$("#errors").html(errors);
		messages.forEach(function(msg){
			errors.append("<li>"+msg+"</li>");
		});
	return false;
	}
	
	
			
	
	return true;
}


/*//<script type="text/javascript">
function alertName(){
alert("Form has been submitted");
} 
//</script> 
*/
