package com.project.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.dao.RegisterManager;
import com.project.entity.Register;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		req.getRequestDispatcher("/WEB-INF/Pages/Login.jsp").forward(req, res);
	}

	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter out = res.getWriter();
		Register r= new Register();
		RegisterManager rm = new RegisterManager();
		
		String Student_name=req.getParameter("Student_name");
		r.setStudent_name(Student_name);
		out.println(Student_name);
		
		String College_name=req.getParameter("College_name");
		r.setCollege_name(College_name);
		
		String Phone_no=req.getParameter("Phone_no");
		r.setPhone_no(Phone_no);
		
		String Adhar_no=req.getParameter("Adhar_no");
		r.setAdhar_no(Adhar_no);
		
		String date_of_birth=req.getParameter("date_of_birth");
		r.setDate_of_birth(Date.valueOf(date_of_birth));
		
		String source=req.getParameter("source");
		r.setSource(source);
		
		String destination=req.getParameter("destination");
		r.setDestination(destination);
		
		String state=req.getParameter("state");
		r.setState(state);
		
		String city=req.getParameter("city");
		r.setCity(city);
		
		String country=req.getParameter("country");
		r.setCountry(country);
		
		String Gender=req.getParameter("Gender");
		r.setGender(Gender);
		
		rm.addUserBook(r);
		
		res.sendRedirect("./GetAllStudentsServlet");
	}

}
