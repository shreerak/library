package com.project.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.dao.RegisterManager;
import com.project.entity.Register;

/**
 * Servlet implementation class Login1Servlet
 */
@WebServlet("/Login1Servlet")
public class Login1Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter out=res.getWriter();
		Register r = new Register();
		
		
		String Adhar_no=req.getParameter("Adhar_no");
		
		
		 
		
		
		if(	RegisterManager.validate1(Adhar_no)){
			

				res.sendRedirect("/GetAllStudentsServlet");
			}
		else{
			req.getRequestDispatcher("/WEB-INF/Pages/home.jsp").forward(req, res);
		}
				
	}

}
