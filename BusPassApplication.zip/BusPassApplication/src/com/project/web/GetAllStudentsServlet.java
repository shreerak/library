package com.project.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.dao.RegisterManager;
import com.project.entity.Register;


@WebServlet("/GetAllStudentsServlet")
public class GetAllStudentsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 RegisterManager rm=new RegisterManager();
		 List<Register> list=rm.getAllStudents();
		   
		 request.setAttribute("register", list);
		request.getRequestDispatcher("WEB-INF/Pages/showstudents.jsp").forward(request, response);
	}


	

}
