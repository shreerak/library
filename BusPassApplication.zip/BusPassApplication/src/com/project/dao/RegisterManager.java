package com.project.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.project.entity.Register;

public class RegisterManager {

	private static Connection OpenConnection() throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		String url = "jdbc:mysql://localhost/library";
		String username = "root";
		String password = "root";
		return DriverManager.getConnection(url,username,password);
	}

	public List<Register> getAllStudents() {
		List<Register> list=new ArrayList<>();
		try(Connection conn=OpenConnection();
				PreparedStatement stmt= conn.prepareStatement("select * from register");
				ResultSet rs = stmt.executeQuery();
				){
				while(rs.next()){
					Register r = new Register();
					
					r.setStudent_name(rs.getString("Student_name"));
					r.setCollege_name(rs.getString("College_name"));
					r.setPhone_no(rs.getString("Phone_no"));
					r.setAdhar_no(rs.getString("Adhar_no"));
					r.setDate_of_birth(rs.getDate("date_of_birth"));
					r.setSource(rs.getString("source"));
					r.setDestination(rs.getString("destination"));
					r.setState(rs.getString("state"));
					r.setCity(rs.getString("city"));
					r.setCountry(rs.getString("country"));
					r.setGender(rs.getString("Gender"));
					list.add(r);
				}
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		return list;
	}
	
	
	public boolean addUserBook(Register r){
		boolean status=false;
		String sql="insert into register values(?,?,?,?,?,?,?,?,?,?,?)";
		
		try(Connection conn=OpenConnection();
				PreparedStatement stmt= conn.prepareStatement(sql);
				){
			stmt.setString(1,r.getStudent_name());
			stmt.setString(2,r.getCollege_name());
			stmt.setString(3, r.getPhone_no());
			stmt.setString(4,r.getAdhar_no());
			stmt.setDate(5,r.getDate_of_birth());
			stmt.setString(6,r.getSource());
			stmt.setString(7,r.getDestination());
			stmt.setString(8,r.getState());
			stmt.setString(9,r.getCity());
			stmt.setString(10,r.getCountry());
			stmt.setString(11,r.getGender());
			
			stmt.executeUpdate();
			//stmt1.setInt(1,(b1.getNo_of_books()-b.getNo_of_books()));
			//stmt1.setInt(2, b1.getBook_id());
			//stmt1.executeUpdate();
			status=true;
			
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return status;
		
	}
	
	public static boolean validate1(String Adhar_no){
		boolean status=false;
		String sql = "select * from register where Adhar_no=?";
		try(Connection conn = OpenConnection();
				PreparedStatement stmt = conn.prepareStatement(sql);
				
				){
					
					stmt.setString(1,Adhar_no);
					//stmt.setString(2,user_id);
					ResultSet rs = stmt.executeQuery();
					status=rs.next();
						//Register r = new Register();
						
						//username=(rs.getString("username"));
						//user_id=(rs.getString("user_id"));
						//status=true;
				
			
		}catch (Exception ex){
			ex.printStackTrace();
		}
		return status;
	}
	
	
	
}
