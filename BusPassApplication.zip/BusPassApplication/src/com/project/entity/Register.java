package com.project.entity;

import java.sql.Date;

public class Register {
	private String Student_name;
	private String College_name;
	private String Phone_no;
	private String Adhar_no;
	private Date date_of_birth;
	private String source;
	private String destination;
	private String state;
	private String city;
	private String country;
	private String Gender;
	
	public Register(){
		
	}

	public Register(String student_name, String college_name, String phone_no, String adhar_no, Date date_of_birth,
			String source, String destination, String state, String city, String country, String gender) {
		super();
		Student_name = student_name;
		College_name = college_name;
		Phone_no = phone_no;
		Adhar_no = adhar_no;
		this.date_of_birth = date_of_birth;
		this.source = source;
		this.destination = destination;
		this.state = state;
		this.city = city;
		this.country = country;
		Gender = gender;
	}

	public String getStudent_name() {
		return Student_name;
	}

	public void setStudent_name(String student_name) {
		Student_name = student_name;
	}

	public String getCollege_name() {
		return College_name;
	}

	public void setCollege_name(String college_name) {
		College_name = college_name;
	}

	public String getPhone_no() {
		return Phone_no;
	}

	public void setPhone_no(String phone_no) {
		Phone_no = phone_no;
	}

	public String getAdhar_no() {
		return Adhar_no;
	}

	public void setAdhar_no(String adhar_no) {
		Adhar_no = adhar_no;
	}

	public Date getDate_of_birth() {
		return date_of_birth;
	}

	public void setDate_of_birth(Date date_of_birth) {
		this.date_of_birth = date_of_birth;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	@Override
	public String toString() {
		return "Register [Student_name=" + Student_name + ", College_name=" + College_name + ", Phone_no=" + Phone_no
				+ ", Adhar_no=" + Adhar_no + ", date_of_birth=" + date_of_birth + ", source=" + source
				+ ", destination=" + destination + ", state=" + state + ", city=" + city + ", country=" + country
				+ ", Gender=" + Gender + "]";
	}

	
}
