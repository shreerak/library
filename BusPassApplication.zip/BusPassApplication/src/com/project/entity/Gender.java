package com.project.entity;

public enum Gender {

	
		MALE, FEMALE

	
}
